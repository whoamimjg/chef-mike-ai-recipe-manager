# Chef Mike's Culinary Classroom

## Overview

Chef Mike's Culinary Classroom is a recipe planning and meal management application successfully converted from Streamlit to React. The application allows users to store recipes, plan meals on a calendar, and generate shopping lists based on their meal plans. It features a clean, user-friendly interface with a blue/green color scheme optimized for mobile and tablet use.

## User Preferences

Preferred communication style: Simple, everyday language.
Framework preference: React - chosen for better UI control and user's familiarity with React development.

## System Architecture

### Frontend Architecture
- **Framework**: React with vanilla JavaScript implementation - converted from Streamlit for better UI flexibility
- **Layout**: Single-page application with navigation bar and dynamic page routing
- **Responsive Design**: Mobile-first design with responsive grid layouts and optimized mobile navigation
- **Styling**: Custom CSS with blue/green gradient theme, card-based layouts, and smooth animations

### Backend Architecture
- **Server**: Express.js with authentication API endpoints
- **Database**: PostgreSQL for user accounts, recipes, meal plans, and preferences
- **Authentication**: Simple token-based authentication (upgradeable to JWT/OAuth)
- **Data Storage**: Database-backed with user-specific data isolation
- **Data Management**: Server-side API with database persistence
- **Architecture Pattern**: Full-stack application with authentication layer

### Key Design Decisions
- **React over Streamlit**: Chosen for better UI control, customization, and user's React experience
- **PostgreSQL Database**: Full multi-user support with proper data isolation and scalability
- **Simple Authentication**: Easy-to-implement system that can be upgraded to OAuth/JWT later
- **Marketing Website Integration**: Single-domain approach with automatic routing based on authentication
- **Component-based Structure**: Modular React components for better code organization and reusability

## Key Components

### Core Application Components
- **server-minimal.js**: Production server using Node.js built-in modules for optimal deployment stability
- **public/**: Static React application files served to users
- **src/**: React source code with modular component architecture
- **Authentication System**: Multi-user support with secure token-based authentication

### React Components
- **App.js**: Main React application entry point with routing and state management
- **Recipes Page**: Recipe CRUD operations, search/filter functionality, import capabilities
- **Meal Planner Page**: Calendar-based meal planning with week/month views
- **Shopping List Page**: Date range-based shopping list generation from meal plans
- **Account Page**: User preferences, dietary restrictions, and subscription management

### System Architecture
- **Clean React Structure**: Removed legacy Streamlit files for optimized deployment
- **Static File Serving**: Efficient serving of React application via minimal Node.js server
- **Database Integration**: PostgreSQL backend with user-specific data isolation

### Recent Changes

### July 26, 2025 - Deployment Configuration Fix and Environment Optimization
- **Fixed Deployment Mismatch**: Resolved .replit configuration trying to run Streamlit commands on Node.js React application
- **Updated Python Entry Point**: Enhanced app.py with robust Node.js availability checking and error handling
- **Environment Verification**: Added Node.js version detection and proper environment variable configuration for deployment
- **Production-Ready Deployment**: Updated deployment entry point to handle both development and production environments correctly
- **Deployment Target Optimization**: Configured for cloudrun deployment target for better Node.js server compatibility
- **Environment Dependencies**: Ensured both Python 3.11 and Node.js 20 are properly installed and available for deployment

### July 26, 2025 - Final Deployment Configuration Fix and Streamlit Compatibility
- **Installed Streamlit for Deployment**: Added Streamlit dependency to satisfy deployment system requirements
- **Created Dual-Mode app.py**: Modified app.py to work both as direct Python launcher and Streamlit-compatible entry point
- **Streamlit Bypass Mode**: When run through streamlit command, app creates simple UI that starts Node.js server in background
- **Deployment Compatibility**: Now works with existing .replit deployment configuration that calls 'streamlit run app.py --server.port 5000'
- **Background Server Management**: Streamlit interface starts and maintains Node.js React server process while providing user feedback
- **Production Server Confirmed**: React server successfully running on port 5000 and responding to HTTP requests
- **Clean Architecture Maintained**: React application remains the primary interface, Streamlit only used for deployment compatibility

### July 27, 2025 - Final Streamlit Elimination and Pure React Deployment
- **Completely Removed Streamlit**: Uninstalled all Streamlit dependencies and eliminated every trace of Streamlit code
- **Fixed Workflow Configuration**: Changed deployment command from `streamlit run app.py` to `python app.py` for direct execution
- **Pure React Server**: app.py now only launches the Node.js React server directly on port 5000 without any Python web framework interference
- **Clean Deployment**: Users access Chef Mike's Culinary Classroom React application directly at deployment URL with zero Streamlit visibility
- **Production Ready**: React server confirmed running successfully on port 5000 with full application functionality

### July 26, 2025 - Deployment Error Resolution and Production Fix
- **Fixed TypeScript Deployment Error**: Resolved npm dependency resolution conflicts preventing package installation
- **Created Minimal Server**: Implemented server-minimal.js using only Node.js built-in modules to bypass npm registry issues
- **Bypassed npm Registry Problems**: Worked around `string-width-cjs` dependency error that was blocking all package installations
- **Maintained Full Functionality**: Preserved all original Express server features while avoiding dependency conflicts
- **Successful Deployment**: App now running successfully on port 5000 with proper static file serving
- **Production-Ready Solution**: Created stable deployment configuration that doesn't rely on problematic npm dependencies
- **Fixed Authentication Redirect Loop**: Resolved endless page reload issue in authentication flow
- **Deployment Routing Issue**: Development environment correctly serves React marketing page, but deployment URL routes to Streamlit compatibility layer
- **Development vs Deployment**: React server running properly on localhost:5000, serving marketing page for unauthenticated users and full app for authenticated users

### July 26, 2025 - Complete Streamlit Removal and Direct React Deployment
- **Removed Streamlit Entirely**: Eliminated all Streamlit components (app.py, .streamlit directory, streamlit dependencies)
- **Direct React Deployment**: Created new app.py that serves as Python entry point but immediately starts the React Node.js server
- **Clean Architecture**: No more dual-system approach - deployment runs React server directly through Python wrapper
- **Fixed Deployment Routing**: Deployment URL now serves React application directly instead of Streamlit compatibility page
- **Simplified Dependencies**: Removed all Python dependencies, using only Node.js built-in modules for the server

### July 26, 2025 - Complete React Conversion + Advanced Features + AI-Powered Suggestions + Authentication System
- **Framework Migration**: Successfully converted entire application from Streamlit to React
- **Modern UI**: Implemented responsive design with blue/green gradient theme and smooth animations
- **Component Architecture**: Created modular React components (Navbar, RecipeCard, RecipeModal, AddRecipeForm)
- **Client-side Data**: Implemented localStorage-based data service for recipes, meal plans, and preferences
- **Express Server**: Set up Node.js/Express server to serve the React application
- **Mobile Optimization**: Enhanced mobile responsiveness with collapsing navigation and touch-friendly controls
- **Recipe Management**: Full CRUD operations with image upload, ingredient parsing, and direction management
- **Modal System**: Interactive recipe viewing with full-screen modals and action buttons
- **Shopping List Generation**: Smart ingredient aggregation from meal plans with category grouping
- **Nutritional Information**: Complete nutrition facts system with FDA-style labels and form integration
- **Interactive Cooking Mode**: Step-by-step navigation with ingredient checklist and built-in timer
- **Print Recipe Functionality**: Clean, formatted print-friendly pages with nutrition facts included
- **Bulk Recipe Management**: Selection mode with checkboxes for multiple recipe operations
- **Monthly Meal Planner**: Full calendar view with drag-and-drop recipe assignment, daily notes, and navigation
- **Enhanced Shopping List**: Grocery store aisle categories with direct item addition and meal plan integration
- **Fixed URL Recipe Import**: Resolved instruction parsing issue where scraped recipes showed individual characters instead of proper cooking steps
- **Real Web Scraping**: Implemented functional recipe extraction from popular cooking websites using Python's recipe-scrapers library
- **Improved Meal Planner Layout**: Independent sidebar scrolling and more spacious calendar cells (220px height) for better drag-and-drop functionality
- **AI-Powered Recipe Suggestions**: Integrated OpenAI API to analyze user inventory and suggest recipes they can make with available ingredients
- **Welcome Popup**: First-time users see AI suggestions automatically upon login to help them get started
- **Smart Shopping Recommendations**: AI suggests ingredients to buy that would unlock multiple recipe possibilities
- **Quick Meal Ideas**: AI identifies recipes perfect for busy schedules based on prep time and available ingredients
- **User API Key Management**: Added Account Settings section allowing users to configure their own OpenAI API keys with connection testing and status indicators
- **PostgreSQL Database Integration**: Implemented full database schema with users, recipes, meal_plans, user_preferences, and inventory tables
- **Simple Authentication System**: Email/password signup and login with secure token-based authentication
- **Marketing Website**: Professional one-page marketing site with signup forms and feature highlights
- **Multi-User Support**: Complete data isolation between users with database-backed persistence
- **Three-Site Architecture**: Separate marketing site (`/`), recipe app (`/app`), and admin panel (`/admin`) with clear navigation between them
- **Upgrade Path**: Authentication system designed to easily upgrade to OAuth, JWT, or third-party services later
- **User Data Isolation**: Implemented user-specific data storage keys so each user has their own isolated recipe collection
- **Clean User Experience**: New users start with empty database and build their own recipe library from scratch
- **Admin Panel System**: Complete admin interface for managing users, payments, and system settings with secure authentication
- **Password Reset Functionality**: Admin can reset user passwords and send password reset emails
- **User Management Tools**: Edit user details, change status (active/trial/inactive), and delete accounts
- **Payment Tracking**: Monitor subscription payments and export financial reports
- **System Administration**: Configure trial periods, pricing, and send bulk emails to users

### July 25, 2025 - Enhanced Recipe Management Features (Streamlit Version)
- **Unit Abbreviation**: Automatic conversion of "tablespoon" to "tbsp" and "teaspoon" to "tsp"
- **Predictive Text**: Dropdown suggestions for common ingredients with custom input fallback
- **Header Rows**: Added checkbox option to create section headers in ingredient lists (e.g., "For the sauce:")
- **Dynamic Rows**: Buttons to add more ingredient and direction rows as needed
- **Card View**: New card-style display option alongside traditional list view
- **Image Upload**: Full image upload functionality with local file upload and URL paste options
- **Thumbnail Display**: Small recipe images displayed next to recipe names in all views
- **Recipe Modal**: Clickable recipe titles open popup dialogs with full recipe details and image display
- **Calendar Integration**: "Add to Meal Planner" button in recipe modals for quick meal planning

## Data Structure
```json
{
  "recipes": [],           // Recipe storage with ingredients, directions, metadata, and images
  "meal_plans": [],        // Calendar-based meal assignments
  "user_preferences": {    // User dietary restrictions and allergies
    "dietary_restrictions": [],
    "allergies": []
  }
}
```

## Data Flow

1. **Recipe Management**: Users add recipes → DataManager stores in JSON → Recipes available for meal planning
2. **Meal Planning**: Users assign recipes to calendar dates → Meal plans stored in JSON
3. **Shopping Lists**: Users select date range → System aggregates ingredients from planned meals → Shopping list generated
4. **Data Persistence**: All changes automatically saved to JSON file through DataManager

## External Dependencies

### Current Dependencies
- **Streamlit**: Web application framework
- **Pandas**: Data manipulation for recipe and meal plan handling
- **Standard Library**: datetime, json, os, uuid, csv, io, re

### Current Integrations
- **OpenAI API**: AI-powered recipe suggestions and meal planning recommendations
- **Python Recipe Scrapers**: Web scraping for recipe import from external websites
- **Stripe API**: Available for future payment processing and subscription management

## Deployment Strategy

### Current Setup
- **Development**: Local Streamlit server
- **Data Storage**: Local JSON file in application directory
- **Session Management**: Streamlit's built-in session state

### Production Considerations
- **Database Migration**: JSON storage should be replaced with PostgreSQL or similar for production
- **User Authentication**: Currently simplified - needs proper auth system
- **File Storage**: Static file storage needed for recipe images and user uploads
- **Scalability**: Current architecture suitable for single-user demo, needs refactoring for multi-user production

### Deployment Requirements
- Python 3.7+ environment
- Streamlit installation
- Write permissions for JSON data file
- Future: Database connection for production deployment

## Development Notes

The application follows a modular structure with clear separation of concerns. The JSON-based storage makes it easy to understand data flow and debug issues. The Streamlit framework provides rapid prototyping capabilities while maintaining a professional user interface.

The architecture is designed to be easily extensible - new pages can be added to the pages directory, and new data management features can be implemented in the utils classes. The current implementation serves as a solid foundation for a production-ready meal planning application.